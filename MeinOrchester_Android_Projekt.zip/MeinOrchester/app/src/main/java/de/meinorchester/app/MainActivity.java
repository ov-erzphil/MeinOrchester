package de.meinorchester.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.net.Uri;
import android.view.*;
import android.widget.*;
import org.json.*;

public class MainActivity extends Activity {
    private LinearLayout root, body;
    private final int blue = Color.rgb(30, 64, 93);
    private android.content.SharedPreferences prefs;
    @Override public void onCreate(Bundle b) { super.onCreate(b); prefs=getSharedPreferences("orchester",MODE_PRIVATE); show("Dienstplan"); }
    private TextView text(String s, int size) { TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(blue);t.setPadding(14,12,14,12);return t; }
    private Button button(String label, Runnable action) { Button b=new Button(this);b.setText(label);b.setOnClickListener(v->action.run());return b; }
    private void show(String page) {
        root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(Color.WHITE);
        TextView title=text("Mein Orchester",26);title.setTextColor(Color.WHITE);title.setBackgroundColor(blue);root.addView(title);
        LinearLayout nav=new LinearLayout(this); for(String name:new String[]{"Dienstplan","Notenarchiv","Mein Konto"}) {Button b=button(name,()->show(name));nav.addView(b,new LinearLayout.LayoutParams(0,65,1));}root.addView(nav);
        ScrollView scroll=new ScrollView(this);body=new LinearLayout(this);body.setOrientation(LinearLayout.VERTICAL);body.setPadding(14,14,14,14);scroll.addView(body);root.addView(scroll);setContentView(root);
        body.addView(text(page,23));
        if(page.equals("Dienstplan")) schedule(); else if(page.equals("Notenarchiv")) scores(); else account();
    }
    private JSONArray getArray(String key) { try {return new JSONArray(prefs.getString(key,"[]"));}catch(Exception e){return new JSONArray();} }
    private void add(String key,String value) {JSONArray a=getArray(key);a.put(value);prefs.edit().putString(key,a.toString()).apply();}
    private void schedule() {
        body.addView(text("Meine Dienste (lokal auf diesem Gerät)",16));
        JSONArray a=getArray("duties");for(int i=0;i<a.length();i++)body.addView(text("• "+a.optString(i),17));
        body.addView(button("Dienst hinzufügen",()->{
            EditText e=new EditText(this);e.setSingleLine(false);e.setHint("Datum, Uhrzeit, Ort und Dienst");
            new AlertDialog.Builder(this).setTitle("Neuer Dienst").setView(e).setNegativeButton("Abbrechen",null).setPositiveButton("Speichern",(d,w)->{if(!e.getText().toString().trim().isEmpty()){add("duties",e.getText().toString().trim());show("Dienstplan");}}).show();
        }));
        body.addView(button("Alle Dienste löschen",()->confirmClear("duties","Dienstplan")));
    }
    private void scores() {
        body.addView(text("PDF-Noten vom Handy auswählen und später wieder öffnen.",16));
        JSONArray a=getArray("scores");for(int i=0;i<a.length();i++){JSONObject item=a.optJSONObject(i);if(item==null)continue;String uri=item.optString("uri");String name=item.optString("name");body.addView(button("♫ "+name,()->{try{Intent intent=new Intent(Intent.ACTION_VIEW);intent.setDataAndType(Uri.parse(uri),"application/pdf");intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(intent);}catch(Exception ex){new AlertDialog.Builder(this).setMessage("Keine PDF-App verfügbar oder Zugriff nicht mehr möglich.").setPositiveButton("OK",null).show();}}));}
        body.addView(button("PDF hinzufügen",()->{Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);i.setType("application/pdf");i.addCategory(Intent.CATEGORY_OPENABLE);startActivityForResult(i,100);}));
        body.addView(button("Archivliste löschen",()->confirmClear("scores","Notenarchiv")));
    }
    @Override protected void onActivityResult(int request,int result,Intent data){super.onActivityResult(request,result,data);if(request==100&&result==RESULT_OK&&data!=null&&data.getData()!=null){Uri uri=data.getData();try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}String name="Noten-PDF "+(getArray("scores").length()+1);EditText e=new EditText(this);e.setText(name);new AlertDialog.Builder(this).setTitle("Titel der Noten").setView(e).setPositiveButton("Speichern",(d,w)->{try{JSONArray a=getArray("scores");JSONObject obj=new JSONObject();obj.put("name",e.getText().toString());obj.put("uri",uri.toString());a.put(obj);prefs.edit().putString("scores",a.toString()).apply();show("Notenarchiv");}catch(Exception ignored){}}).setNegativeButton("Abbrechen",null).show();}}
    private void account(){body.addView(text("Persönliche Angaben – nur lokal gespeichert",16));EditText name=new EditText(this);name.setHint("Name");name.setText(prefs.getString("name",""));body.addView(name);EditText instrument=new EditText(this);instrument.setHint("Instrument");instrument.setText(prefs.getString("instrument",""));body.addView(instrument);body.addView(button("Angaben speichern",()->{prefs.edit().putString("name",name.getText().toString()).putString("instrument",instrument.getText().toString()).apply();Toast.makeText(this,"Gespeichert",Toast.LENGTH_SHORT).show();}));body.addView(text("Noch keine Anmeldung, Cloud-Synchronisierung oder Verwaltung durch ein Orchester eingerichtet.",14));}
    private void confirmClear(String key,String page){new AlertDialog.Builder(this).setTitle("Wirklich löschen?").setMessage("Die gespeicherten Einträge dieser Rubrik werden entfernt.").setNegativeButton("Abbrechen",null).setPositiveButton("Löschen",(d,w)->{prefs.edit().remove(key).apply();show(page);}).show();}
}
